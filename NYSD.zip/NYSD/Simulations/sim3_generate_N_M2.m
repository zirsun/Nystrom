clear;
tic
loadPath = cd;
addpath(genpath([loadPath '\KRR_tool']));

Ncross = [2000,5000,10000,20000,50000];   % Number of Training Sample
test_N = 10;
ExNum = 5;
sampleratio = 0.002;  % sampleratio = 0.002,0.005,0.01,0.5
V=0;
lambdacross = [1:0.1:2];
KernelType = 2;
KerPara.KernelType = KernelType;

for p = 1:length(Ncross)
    N = Ncross(p);
    for Ex = 1:ExNum
        kk=0;
        for lambdac = lambdacross
            kk=kk+1;
            lambda = lambdac/(10000);
            % set seed
            rand('seed', Ex)
            randn('seed', Ex)
            % Generating Samples
            y(1)= rand(1);
            for i =2:(N+test_N+1)
                if rand(1)>=0.5
                    e(i) = 0.5;
                else
                    e(i) = 0;
                end
                y(i) = 0.5*y(i-1)+e(i);
            end
            % Generating Test Set
            test_x = y(N+1:N+test_N)';
            test_y = y(N+2:N+test_N+1)';
            
            % Generating Train Set
            train_x = y(1:N)';
            train_y = y(2:N+1)';
            a = V;
            train_xm = y(1:a+1:1+(N*sampleratio-1)*(a+1))';         
            hat_y = SKernelRidge_sub(train_x,train_y,test_x,train_xm,lambda, KerPara);  % BaseLine
            % Compute RMSE
            testRMSE_Baseline = sqrt(mean((test_y-hat_y-e(N+2:N+test_N+1)'+0.25).^2));
            testRMSE_line_Mean(p,Ex,kk) = testRMSE_Baseline;
        end
    end
end
RMSE = min(mean(testRMSE_line_Mean,2),[],3);
save ('C:\data\bernoulli_50000N_ExNum5_0002sampleratio','RMSE')
% plot(Ncross,RMSE);
toc