clear;
tic
loadPath = cd;
addpath(genpath([loadPath '\KRR_tool']));

N = 2000;   % Number of Training Sample
test_N = 50;
ExNum = 5;
sampleratio = 0.01;
V=0;
lambdacross = [1:1:20];
KernelType = 2;
KerPara.KernelType = KernelType;
% testMSE_Baseline = zeros(1,length(V));

for Ex = 1:ExNum
    kk=0;
    for lambdac = lambdacross
        kk=kk+1;
        lambda = lambdac/(2000);
        % set seed
        rand('seed', Ex)
        randn('seed', Ex)
        % Generating Samples
        y(1)= rand(1);
        for i =2:(N+test_N+1)
            e(i) = rand(1)*1.4-0.7;
            y(i) = f1(y(i-1))+e(i);
        end
        % Generating Test Set
        test_x = y(N+1:N+test_N)';
        test_y = y(N+2:N+test_N+1)';       
        % Generating Train Set
        train_x = y(1:N)';
        train_y = y(2:N+1)';
        for iter = 1:length(V)
            a = V(iter);
            train_xm = y(1:a+1:1+(N*sampleratio-1)*(a+1))';  % The sub-sampling interval is a          
            hat_y = SKernelRidge_sub(train_x,train_y,test_x,train_xm,lambda, KerPara);  % BaseLine           
            testRMSE_Baseline(iter) = sqrt(mean((test_y-hat_y-e(N+2:N+test_N+1)').^2));  % Compute RMSE
        end
        testRMSE_line_Mean(Ex,:,kk) = testRMSE_Baseline;
    end
end
testRMSE_Baseline_Mean = min(mean(testRMSE_line_Mean,1),[],3);
disp(['ratio:',num2str(sampleratio),'  loss��',num2str(testRMSE_Baseline_Mean)])
toc
