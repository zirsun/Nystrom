clear;
loadPath = cd;
addpath(genpath([loadPath '\KRR_tool']));
filename ='C:\NYSD_code\wti-daily_csv.csv';
y = csvread(filename,1,1);
y = y (:,1);
y = y';
N = 4000;     % Number of Training Sample: N =4000 for Forecasting, N =3000 for ACF, Noise-extractor and Statistical bar
test_N = 100;     % test_N = 100 for Forecasting and Noise-extractor, test_N = 200 for ACF, test_N = 500 for Statistical bar
Ex = 1;
sampleratio = 0.1;
a=0;
KernelType = 1;
KerPara.KernelType = KernelType;
lambda = 4/(N);
% set seed
rand('seed', Ex)
randn('seed', Ex)

% Generating Test Set
test_x = y(N+1:N+test_N)';
test_y = y(N+2:N+test_N+1)';

% Generating Train Set
train_x = y(1:N)';
train_y = y(2:N+1)';

train_xm = y(1:a+1:1+(N*sampleratio-1)*(a+1))';
hat_y = SKernelRidge_sub(train_x,train_y,test_x,train_xm,lambda, KerPara);
predict_noise = test_y-hat_y;

plot(test_y,'linew',2)            % Forecasting
hold on
plot(hat_y,'linew',2)
legend('Real Trend','Prediction')
xlabel('t')

figure(2)              % ACF
autocorr(test_y,test_N-1);

figure(3)              % Noise-extractor
plot(predict_noise,'linew',2)
legend('predicted noise')
 
figure(4)              % Statistical bar
predict_noise = test_y-hat_y;
bar([-1.1:0.2:1.1],[sum((predict_noise<-1).*(predict_noise>=-1.2)),sum((predict_noise<-.8).*(predict_noise>=-1)),sum((predict_noise<-.6).*(predict_noise>=-.8)),sum((predict_noise<-.4).*(predict_noise>=-.6)),...
    sum((predict_noise<-.2).*(predict_noise>=-.4)),sum((predict_noise<0).*(predict_noise>=-.2)),sum((predict_noise<.2).*(predict_noise>=0)),sum((predict_noise<.4).*(predict_noise>=.2)),sum((predict_noise<.6).*(predict_noise>=.4)),sum((predict_noise<.8).*(predict_noise>=.6)),sum((predict_noise<1).*(predict_noise>=.8)),sum((predict_noise<1.2).*(predict_noise>=1))]/test_N)
