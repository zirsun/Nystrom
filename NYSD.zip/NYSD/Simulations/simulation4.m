clear;
tic
loadPath = cd;
addpath(genpath([loadPath '\KRR_tool']));

N = 2000;        % Number of Training Sample
test_N = 50;     % test_N = 2000 for statistical bar, else test_N = 50
Ex = 5;          % Ex = 5 for bernoulli noise and uniform noise, Ex = 7 for gaussian noise
sampleratio = 0.01;
a=0;
KernelType = 2;
KerPara.KernelType = KernelType;
lambda = 10/(2000);
% set seed
rand('seed', Ex)
randn('seed', Ex)
% Generating Samples
y(1)= rand(1);
for i =2:(N+test_N+1)
    e(i) = rand(1)*0.4-0.2;      %% U[-0.2,0.2]
    %     e(i) = randn(1)*0.1;   %% N(0,0.1^2)
    
    %     if rand(1)>=0.5        %% B(0.5)
    %         e(i) = 1;
    %     else
    %         e(i) = 0;
    %     end
    y(i) = f1(y(i-1))+e(i);
end
% Generating Test Set
test_x = y(N+1:N+test_N)';
test_y = y(N+2:N+test_N+1)';

% Generating Train Set
train_x = y(1:N)';
train_y = y(2:N+1)';

train_xm = y(1:a+1:1+(N*sampleratio-1)*(a+1))';
hat_y = SKernelRidge_sub(train_x,train_y,test_x,train_xm,lambda, KerPara);

predict_noise = test_y-hat_y;    % for uniform noise or gaussian noise
% predict_noise = test_y-hat_y+0.5;   % for bernoulli noise 

figure(1)
plot(e(N+2:N+test_N+1),'linew',2);
hold on
plot(predict_noise,'linew',2)
xlabel('t','FontName','Times New Roman')
legend('FontName','Times New Roman')
legend('real noise','predicted noise')

figure(2)
plot(test_y-e(N+2:N+test_N+1)','linew',2)          % for uniform noise or gaussian noise
% plot(test_y-e(N+2:N+test_N+1)'+0.5,'linew',2)    % for bernoulli noise 
hold on ;
plot(hat_y,'linew',2)
xlabel('t','FontName','Times New Roman')
legend('FontName','Times New Roman')
legend('Label without noise','Prediction')

figure(3)
plot(test_y,'linew',2)
hold on ;
plot(hat_y,'linew',2)
xlabel('t','FontName','Times New Roman')
legend('FontName','Times New Roman')
legend('Label with noise','Prediction')

figure(4)
%%% uniform noise U[-0.2,0.2] or bernoulli noise B(0.5)
bar([-1.1,-0.9,-0.7,-0.5,-0.3,-0.1,0.1,0.3,0.5,0.7,0.9,1.1,1.3],[sum(predict_noise<-1),sum((predict_noise<-0.8).*(predict_noise>=-1)),sum((predict_noise<-0.6).*((predict_noise>=-0.8))),sum((predict_noise<-0.4).*((predict_noise>=-0.6))),sum((predict_noise<-0.2).*((predict_noise>=-0.4))),sum((predict_noise<0).*((predict_noise>=-0.2))),sum((predict_noise<0.2).*((predict_noise>=0))),sum((predict_noise<0.4).*((predict_noise>=0.2))),sum((predict_noise<0.6).*((predict_noise>=0.4))),sum((predict_noise<0.8).*((predict_noise>=0.6))),sum((predict_noise<1).*((predict_noise>=0.8))),sum((predict_noise<1.2).*((predict_noise>=1))),sum(predict_noise>=1.2)]/test_N)
ylabel('Frequency','FontName','Times New Roman')

%%% gaussian noise N(0,0.1^2)
% bar([-0.4,-0.25,-0.15,-0.05,0.05,0.15,0.25,0.4],[sum(predict_noise<-0.3),sum((predict_noise<-0.2).*(predict_noise>=-0.3)),sum((predict_noise<-0.1).*(predict_noise>=-0.2)),sum((predict_noise<0).*(predict_noise>=-0.1)),sum((predict_noise<0.1).*(predict_noise>=0)),sum((predict_noise<0.2).*(predict_noise>=0.1)),sum((predict_noise<0.3).*(predict_noise>=0.2)),sum(predict_noise>=0.3)]/test_N)
% ylabel('Frequency','FontName','Times New Roman')

toc
