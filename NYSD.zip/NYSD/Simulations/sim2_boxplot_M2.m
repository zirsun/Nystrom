clear;
tic
loadPath = cd;
addpath(genpath([loadPath '\KRR_tool']));

% N = 2000;     % Number of Training Sample
N = 10000;      % Number of Training Sample
test_N = 5;
ExNum = 20;
sampleratio = 0.01;

V = [-2,-1,0,5,10,15,20,50,100];
% lambdacross = [1:0.1:2];         % for N = 2000
lambdacross = [0.2:0.04:0.8];      % for N = 10000
KernelType = 2;
KerPara.KernelType = KernelType;

for Ex = 1:ExNum
    kk=0;
    for lambdac = lambdacross
        kk=kk+1;
        lambda = lambdac/(2000);
        % set seed
        rand('seed', Ex)
        randn('seed', Ex)
        % Generating Samples
        y(1)= rand(1);
        for i =2:(N+test_N+1)
            if rand(1)>=0.5
                e(i) = 0.5;
            else
                e(i) = 0;
            end
            y(i) = 0.5*y(i-1)+e(i);
        end
        % Generating Test Set
        test_x = y(N+1:N+test_N)';
        test_y = y(N+2:N+test_N+1)';
        
        % Generating Train Set
        train_x = y(1:N)';
        train_y = y(2:N+1)';
        for iter = 1:length(V)
            a = V(iter);
            if a==-2      
                train_xm = y(N-N*sampleratio+1:1:N)';   % Last
            elseif a==-1                  
                train_xm = y(int32(N/2)-floor(N*sampleratio)+1:1:int32(N/2))';   % Middle
            else         
                train_xm = y(1:a+1:1+(N*sampleratio-1)*(a+1))'; 
            end
            hat_y = SKernelRidge_sub(train_x,train_y,test_x,train_xm,lambda, KerPara);         
            testRMSE_Baseline(iter) = sqrt(mean((test_y-hat_y-e(N+2:N+test_N+1)'+0.25).^2));   % Compute RMSE
        end
        testRMSE_line_Mean(Ex,:,kk) = testRMSE_Baseline;
    end
end
testRMSE_Baseline_Mean = min(mean(testRMSE_line_Mean,1),[],3);
figure(1)
boxplot(min(testRMSE_line_Mean,[],3),'Labels',{'Last','Middle','First','Intv. 5','Intv. 10','Intv. 15','Intv. 20','Intv. 50','Intv. 100'})
ylabel('RMSE')
ax = gca;
set(gca, 'XTickLabelRotation', 45)
toc