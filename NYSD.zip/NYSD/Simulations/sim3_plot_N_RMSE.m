clear;
Ncross =[2000,5000,10000,20000,50000];
load('C:\data\50000N_ExNum5_uni_05sampleratio')
plot(Ncross,MSE(2:6),'linew',1.5); hold on;
load('C:\data\50000N_ExNum5_uni_001sampleratio')
Ncross =[2000,5000,10000,20000,50000];
plot(Ncross,MSE(2:6),'linew',1.5); hold on;
load('C:\data\50000N_ExNum5_uni_0005sampleratio')
Ncross =[2000,5000,10000,20000,50000];
plot(Ncross,MSE(2:6),'linew',1.5); hold on;
load('C:\data\50000N_ExNum5_uni_0002sampleratio')
Ncross =[2000,5000,10000,20000,50000];
plot(Ncross,MSE(2:6),'linew',1.5); 
legend('0.5 Sub-sampling Ratio','0.01 Sub-sampling Ratio','0.005 Sub-sampling Ratio','0.002 Sub-sampling Ratio')
xlabel('Training Samples N');
ylabel('RMSE');
xlim([2000,50000])

figure(2);
Ncross =[2000,5000,10000,20000,50000];
load('C:\data\bernoulli_50000N_ExNum5_05sampleratio')
plot(Ncross,MSE(2:6),'linew',1.5); hold on;
load('C:\data\bernoulli_50000N_ExNum5_001sampleratio')
plot(Ncross,MSE(2:6),'linew',1.5); hold on;
load('C:\data\bernoulli_50000N_ExNum5_0005sampleratio')
plot(Ncross,MSE(2:6),'linew',1.5); hold on;
load('C:\data\bernoulli_50000N_ExNum5_0002sampleratio')
plot(Ncross,MSE(2:6),'linew',1.5); 
legend('0.5 Sub-sampling Ratio','0.01 Sub-sampling Ratio','0.005 Sub-sampling Ratio','0.002 Sub-sampling Ratio')
xlabel('Training Samples N');
ylabel('RMSE');
xlim([2000,50000])