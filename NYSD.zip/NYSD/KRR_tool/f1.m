function [ y ] = f1( x )
y = 0.5*sin(x);

end

