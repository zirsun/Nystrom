function hat_y = SKernelRidge_downsample(in_data,out_data,test_data,lamda, KerPara,  samplerate, sample_method)
%
%
% This function performs the kernel ridge regression using the Simple Kernel. 
%
% in_data - Input to the functio to be regressed.  N (points) x D (dimensional)
% out_data - Ouput of the function to be regressed. N x 1 (points)
% test_data - Input of testing set. n (points) x D (dimensions) 
% lamda - Regularization Parameter. (Carefully choose this)
% hat_y - Output for the testing set test_data (those that were not in training) n x 1 (points)  


if size(in_data,1) ~= size(out_data,1)
    fprintf('\nTotal number of points for function input and output are unequal');
    fprintf('\n Exitting program');
    return
elseif size(test_data,2) ~= size(in_data,2)
    fprintf('\nTest data and Input data are of unequal dimensions');
    fprintf('\nExitting program')
    return
else
    N = size(in_data,1);
    switch sample_method
        case 1
            sample_idx = N:-1:N-N*samplerate+1; %%%����N*samplerate ��
        case 2
            sample_idx = 1:1:N*samplerate;%%%ǰ��N*samplerate ��
        case 3
            sample_idx = (floor(N/2)-floor(N*samplerate/2)):1:(floor(N/2)+floor(N*samplerate/2));%%%�м�N*samplerate ��
        case 4
            sample_idx = 1:2:1+(N*samplerate-1)*2;%%%���1������
        case 5
            sample_idx = 1:4:1+(N*samplerate-1)*4;%%%���3������
    end
    data_m = in_data(sample_idx,:);
    %% Compute K(x,x') on training set  
    Knm = KernelComputation(in_data, data_m, KerPara);
    Kmm = KernelComputation(data_m, data_m, KerPara);
    %% Compute K(x, x') on training and testing set
    Ktetr = KernelComputation(test_data,data_m,KerPara);
    %% Compute hat_y
    %hat_y = Ktetr*((Knm'*Knm + lamda*Kmm*N)^(-1)*Knm'*out_data);
    hat_y = Ktetr*(pinv(Knm'*Knm + lamda*Kmm*N)*Knm'*out_data);
end
