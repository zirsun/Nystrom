function [ y ] = f5( x )
y = 10*sqrt(-x)*sin(8*pi*x)*(x<0)*(x>=-0.25);

end

