function [ y ] = f2( x,z )
y = cos(x)*sin(z);
% y=0.5*x+0.1*z;

end

