function [ y ] = f4( x )
y = 2*max(1,min(3+2*x,3-8*x));

end

